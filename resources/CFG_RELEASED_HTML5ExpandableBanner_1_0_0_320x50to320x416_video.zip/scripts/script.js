/*******************
VARIABLES
*******************/
var creativeVersion = "1.0.0"; // format version code, please do not alter or remove this variable
var creativeLastModified = "2015-10-29";

var bannerDiv;
var expandButton;
var sdkData;

/*******************
INITIALIZATION
*******************/
function checkIfAdKitReady(event)
{
	adkit.onReady(initializeCreative);
}

function initializeCreative()
{
	initializeGlobalVariables();
	initializeCloseButton();
	addEventListeners();
}

function initializeGlobalVariables()
{
	bannerDiv = document.getElementById("banner");
	expandButton = document.getElementById("expandButton");	
	
	sdkData = EB.getSDKData();
}

function initializeCloseButton()
{
	var enableSDKDefaultCloseButton = EB._adConfig && EB._adConfig.hasOwnProperty("mdEnableSDKDefaultCloseButton") ? EB._adConfig.mdEnableSDKDefaultCloseButton : false;
	if (sdkData !== null)
	{
		if (sdkData.SDKType === "MRAID" && !enableSDKDefaultCloseButton)
		{
			// set sdk to use custom close button
			EB.setExpandProperties({useCustomClose: true});
		}
	}
}

function addEventListeners()
{
	expandButton.addEventListener("click", handleExpandButtonClick);
}

/*******************
EVENT HANDLERS
*******************/
function handleExpandButtonClick()
{
	// to expand a specific panel
	EB.expand({panelName: "expand"});
	// to expand default panel
	// EB.expand();
}

/*******************
UTILITIES
*******************/
function expand()
{
	handleExpandButtonClick();
}

function collapse()
{
	EB.collapse();
}

window.addEventListener("load", checkIfAdKitReady);