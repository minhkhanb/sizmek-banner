/*******************
VARIABLES
*******************/
var expansionDiv;
var closeButton;
var userActionButton;
var clickthroughButton;
var videoContainer;
var video;
var videoTrackingModule;
var sdkVideoPlayer;
var sdkVideoPlayButton;
var sdkData;
var isWindowsPhone = (/windows phone/i).test(navigator.userAgent);

/*******************
INITIALIZATION
*******************/
function checkIfAdKitReady(event)
{
	adkit.onReady(initializeCreative);
}

function initializeCreative()
{
	initializeGlobalVariables();
	initializeCloseButton();
	initializeVideo();
	addEventListeners();
}

function initializeGlobalVariables()
{
	expansionDiv = document.getElementById("expansion");
	closeButton = document.getElementById("closeButton");
	userActionButton = document.getElementById("userActionButton");
	clickthroughButton = document.getElementById("clickthroughButton");
	videoContainer = document.getElementById("videoContainer");
	video = document.getElementById("video");
	sdkVideoPlayer = document.getElementById("sdkVideoPlayer");
	sdkVideoPlayButton = document.getElementById("sdkVideoPlayButton");
	
	sdkData = EB.getSDKData();
}

function initializeCloseButton()
{
	var enableSDKDefaultCloseButton = EB._adConfig && EB._adConfig.hasOwnProperty("mdEnableSDKDefaultCloseButton") ? EB._adConfig.mdEnableSDKDefaultCloseButton : false;
	if (sdkData !== null && sdkData !== undefined)
	{
		if (sdkData.SDKType === "MRAID" && !enableSDKDefaultCloseButton)
		{
			closeButton.style.display = "block";
		}
	}
	else
	{
		closeButton.style.display = "block";
	}
}

function initializeVideo()
{
	var useSDKVideoPlayer = false;
	var sdkPlayerVideoFormat = EB._adConfig && EB._adConfig.hasOwnProperty("mdSDKVideoFormat") ? EB._adConfig.mdSDKVideoFormat : "mp4";
	var enableSDKVideoPlayer = EB._adConfig && EB._adConfig.hasOwnProperty("mdEnableSDKVideoPlayer") ? EB._adConfig.mdEnableSDKVideoPlayer : true;
	var autoPlayVideo = EB._adConfig && EB._adConfig.hasOwnProperty("mdAutoPlayVideo") ? EB._adConfig.mdAutoPlayVideo : false;	
	
	if (sdkData !== null && sdkData !== undefined) {
		if (sdkData.SDKType === "MRAID" && sdkData.version > 1 && enableSDKVideoPlayer)
		{
			var sourceTags = video.getElementsByTagName("source");
			var videoSource = "";
			for (var i = 0 ; i < sourceTags.length; i ++)
			{
				if (sourceTags[i].getAttribute("type"))
				{
					if (sourceTags[i].getAttribute("type").toLowerCase() === "video/" + sdkPlayerVideoFormat.toLowerCase())
					{
						videoSource = sourceTags[i].getAttribute("src");
					}
				}
			}
			if (videoSource !== "")
			{
				sdkVideoPlayButton.addEventListener("click", function()
				{
					//EB.playVideoOnNativePlayer(videoSource); /* CURRENTLY NOT WORKING FROM PANEL, USE BELOW WORKAROUND */
					
					var videoTracking;
					if (videoSource.match(/http:\/\//i) === null && videoSource.match(/https:\/\//i) === null)
					{
						if (document.location.toString().match(/panels\/.+\//i) !== null)
						{
							videoSource = document.location.toString().match(/panels\/.+\//i) + videoSource;
							videoTracking = EB._getAsset(videoSource).dsPath;
							videoSource = EB.getAssetUrl(videoSource);
						}
						else
						{
							videoSource = document.location.toString().split("index.html")[0] + videoSource;
							if (videoSource.match(/site-.+/i) !== null)
							{
								videoTracking = videoSource.match(/site-.+/i);
							}
						}
					}					
					if (!videoTracking)
					{
						videoTracking = EBG.Video.EXTERNAL_ASSET;
					}
					EB.videoInteraction(EBG.VideoInteraction.STARTED, videoTracking, !0);
					EB._sendMessage(EBG.EBMessage.PLAY_VIDEO_ON_NATIVE_PLAYER, {videoUrl: videoSource});
				});
				videoContainer.removeChild(video);
				video = null;
				useSDKVideoPlayer = true;
			}
		}
	}
	if (!useSDKVideoPlayer)
	{
		videoContainer.removeChild(sdkVideoPlayer);
		videoTrackingModule = new EBG.VideoModule(video);
		if (isWindowsPhone)
		{
			video.addEventListener("click", function(event)
			{
				var videoWidth = getStyle(this, "width");
				var videoHeight = getStyle(this, "height");
				if(videoWidth < 168 || videoHeight < 152)
				{
					video.play();
				}
			}, false);			
		}
	}
	videoContainer.style.visibility = "visible";
	if (!useSDKVideoPlayer && autoPlayVideo)
	{
		videoTrackingModule.playVideo(false);
	}	
}

function addEventListeners()
{
	closeButton.addEventListener("click", handleCloseButtonClick);
	userActionButton.addEventListener("click", handleUserActionButtonClick);
	clickthroughButton.addEventListener("click", handleClickthroughButtonClick);
}

/*******************
EVENT HANDLERS
*******************/
function handleCloseButtonClick()
{
	pauseVideo();
	setTimeout(function() {
		// to collapse a specific panel
		EB.collapse({panelName: "expand"});
		// to collapse all the panels
		// EB.collapse();
	}, 200);
}

function handleUserActionButtonClick()
{
	pauseVideo();
	EB.userActionCounter("CustomInteraction");
}

function handleClickthroughButtonClick()
{
	pauseVideo();
	EB.clickthrough();
}

/*******************
UTILITIES
*******************/
function pauseVideo()
{
	if (video)
	{
		video.pause();
	}
}

function getStyle(obj, styleName)
{
	try
	{
		if (typeof document.defaultView !== "undefined" && typeof document.defaultView.getComputedStyle !== "undefined")
		{
			return document.defaultView.getComputedStyle(obj, "")[styleName];
		}
		else if (typeof obj.currentStyle !== "undefined")
		{
			return obj.currentStyle[styleName];
		}
		else
		{
			return obj.style[styleName];
		}
		return null;
	}
	catch (error)
	{
		return null;
	}
}

window.addEventListener("load", checkIfAdKitReady);